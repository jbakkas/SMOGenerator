SARSMutOnto Generator is a tool that allows the automatic generation of the SARSMutOnto ontology. This tool depends on the following modules:
BeautifulSoup, owlready2, wxPython, firefox-geckodriver.
Steps to run the SARSMutOnto Generator:

I)Install the dependent modules:
   1) pip install selenium
   2) pip install owlready2
   1) pip install BeautifulSoup
   3) pip3 install -U -f https://extras.wxpython.org/wxPython4/extras/linux/gtk3/ubuntu-20.04 wxPython
   4) sudo apt-get install firefox-geckodriver
  
II) This tool is developed using the geckodriver API which is an implementation of the Selenium WebDriver specification made for fireFoxe browser. It is necessary to download and configure its location which is initially set at "./WebDriver/bin/geckodriver.exe".

